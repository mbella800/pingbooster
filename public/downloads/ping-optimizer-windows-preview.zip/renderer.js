const gameName = document.querySelector("#game-name");
const gameLabel = document.querySelector("#game-label");
const gameSelect = document.querySelector("#game-select");
const detectionState = document.querySelector("#detection-state");
const optimizeButton = document.querySelector("#optimize");
const optimizeLabel = document.querySelector("#optimize-label");
const badge = document.querySelector("#evidence-badge");
const toast = document.querySelector("#toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 4200);
}

function setMetric(id, value, status) {
  document.querySelector(`#metric-${id}`).firstChild.textContent = value ?? "—";
  document.querySelector(`#${id}-status`).textContent = status;
}

function probe(url, timeout = 2500) {
  return new Promise((resolve) => {
    const image = new Image();
    const started = performance.now();
    let settled = false;
    const timer = window.setTimeout(() => finish(null), timeout);
    function finish(value) {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      image.src = "";
      resolve(value);
    }
    image.onload = () => finish(Math.round(performance.now() - started));
    image.onerror = () => finish(Math.round(performance.now() - started));
    image.src = `${url}?po=${Date.now()}-${Math.random()}`;
  });
}

async function measure(target) {
  const samples = [];
  for (let attempt = 0; attempt < 5; attempt += 1) {
    samples.push(await probe(target.url));
  }
  const valid = samples.filter(Number.isFinite);
  const sorted = [...valid].sort((a, b) => a - b);
  const latency = sorted.length ? sorted[Math.floor(sorted.length / 2)] : null;
  const average = valid.length ? valid.reduce((sum, value) => sum + value, 0) / valid.length : 0;
  const variance = valid.length
    ? valid.reduce((sum, value) => sum + (value - average) ** 2, 0) / valid.length
    : 0;
  return {
    name: target.name,
    latency,
    jitter: valid.length ? Math.round(Math.sqrt(variance)) : null,
    loss: Math.round(((samples.length - valid.length) / samples.length) * 100),
  };
}

async function runDiagnostics() {
  const targets = [
    { name: "Cloudflare web edge", url: "https://www.cloudflare.com/favicon.ico" },
    { name: "Google web edge", url: "https://www.google.com/favicon.ico" },
    { name: "Quad9 web edge", url: "https://www.quad9.net/favicon.ico" },
  ];
  const results = [];
  for (const target of targets) results.push(await measure(target));
  const best = results.filter((result) => result.latency !== null).sort((a, b) => a.latency - b.latency)[0];
  return best ?? null;
}

gameSelect.addEventListener("change", () => {
  gameName.textContent = gameSelect.value;
  gameLabel.textContent = "SELECTED GAME";
  detectionState.textContent = "MANUAL";
});

optimizeButton.addEventListener("click", async () => {
  optimizeButton.disabled = true;
  optimizeLabel.textContent = "MEASURING CONNECTION";
  badge.textContent = "TESTING";
  try {
    const best = await runDiagnostics();
    if (!best) throw new Error();
    setMetric("latency", best.latency, best.name);
    setMetric("jitter", best.jitter, best.jitter <= 35 ? "Stable web response" : "Variable web response");
    setMetric("loss", best.loss, best.loss === 0 ? "No failed requests" : "Some requests failed");
    document.querySelector("#route-detail").textContent = `Fastest web edge: ${best.name}`;
    document.querySelector("#jitter-detail").textContent = `${best.jitter} ms response variation`;
    document.querySelector("#loss-detail").textContent = `${best.loss}% of browser requests failed`;
    document.querySelector("#best-path").textContent = "Direct route retained";
    badge.textContent = "MEASURED";
    badge.classList.add("good");
    optimizeLabel.textContent = "DIRECT ROUTE IS ACTIVE";
    document.querySelectorAll(".evidence-item i b").forEach((bar, index) => {
      bar.style.width = index < 3 ? `${78 - index * 7}%` : "18%";
    });
    showToast("Preview diagnosis complete. Browser response was measured; game traffic was not rerouted.");
  } catch {
    optimizeLabel.textContent = "TRY DIAGNOSIS AGAIN";
    badge.textContent = "UNAVAILABLE";
    showToast("The preview could not reach its measurement targets. No settings were changed.");
  } finally {
    optimizeButton.disabled = false;
  }
});

document.querySelector("#minimize").addEventListener("click", () => showToast("Window controls are available in the installed app."));
document.querySelector("#close").addEventListener("click", () => window.close());
detectionState.textContent = "MANUAL";
