@echo off
set "preview=%~dp0PingOptimizerPreview.html"
where msedge.exe >nul 2>nul
if %errorlevel%==0 (
  start "" msedge.exe --app="%preview%"
) else (
  start "" "%preview%"
)
