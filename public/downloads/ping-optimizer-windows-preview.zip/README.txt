PING OPTIMIZER — WINDOWS TECHNICAL PREVIEW

This preview demonstrates the planned interface, automatic detection for popular
running games, and real connection-response diagnostics.

The production relay network is not active in this build. It does not reroute
game traffic or claim to lower ping.

Run "Launch Ping Optimizer.cmd" to open the lightweight preview. If Microsoft
Edge is available, it opens in a clean app-style window; otherwise it opens in
your default browser.

This lightweight download is not an installer and does not contain the full
desktop executable. Do not redistribute it as a production release.
